//  Copyright (c) 2012 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com              Last revised 23 December 2012

#include <mpi.h>

#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include <cerrno>
#include <cstdlib>
#include <cstring>

#include <limits.h>
#include <unistd.h>
#include <sys/syscall.h>

#include "reporter.h"

using std::cerr; using std::cout; using std::endl;
using std::ostringstream;
using std::string;
using std::vector;

string message_prefix;

int main (int argc, char *argv[])
{
/*
 *  Set up the message prefix string
 */

  pid_t pid = getpid ();

  char hostname[HOST_NAME_MAX];
  if (gethostname (hostname, HOST_NAME_MAX) == -1) {
    cerr << argv[0] << ": "
         << "process " << pid << ": gethostname: " << strerror (errno) << "."
         << endl;
    return EXIT_FAILURE;
  }

  ostringstream mps;
  mps << argv[0] << " (PID " << pid << " on host " << hostname << "): ";
  message_prefix = mps.str ();

/*
 *  Normal MPI startup
 */

  (void) MPI_Init (&argc, &argv);
  int processRank;
  (void) MPI_Comm_rank (MPI_COMM_WORLD, &processRank);

/*
 *  Start timestamp
 */

  string t_start = hrt ();
  cout << message_prefix
       << "MPI process " << processRank << ": execution started at " << t_start << "." << endl;

/*
 *  Establish the pause interval
 */

  double interval;
  if (argc == 1)
    interval = 0.;
  else if (argc == 2) {
    char *unconv;
    interval = strtod (argv[1], &unconv);
    if (strlen (unconv) > 0) {
      if (processRank == 0)
        cerr << message_prefix
             << "string " << argv[1] << " cannot be converted to double."
             << endl;
      (void) MPI_Abort (MPI_COMM_WORLD, EXIT_FAILURE);
    }
    if (interval < 0.) {
      if (processRank == 0)
        cerr << message_prefix
             << "interval (specified as " << argv[1] << ") must be nonnegative."
             << endl;
      (void) MPI_Abort (MPI_COMM_WORLD, EXIT_FAILURE);
    }
  }
  else {
    if (processRank == 0)
      cerr << "Usage: " << argv[0] << " [interval]" << endl
           << " interval is a nonnegative number." << endl;
    (void) MPI_Abort (MPI_COMM_WORLD, EXIT_FAILURE);
  }

/*
 *  Establish the list of logical CPUs
 */

  vector<unsigned> lCPUID = getCPUIDs ();

/*
 *  Establish the CPU affinity of this process
 */

  string CPUAffinity = getCPUAffinity (lCPUID, pid);
  cout << message_prefix
       << "MPI process " << processRank << ": can be scheduled to logical CPU(s) " << CPUAffinity << "."
       << endl;

/*
 *  Establish and output the memory affinity of this process
 */

  string MemoryAffinity = getMemoryAffinity ();
  cout << message_prefix
       << "MPI process " << processRank << ": " << MemoryAffinity << "."
       << endl;

/*
 *  Execute the pause
 */

  pause (interval);

/*
 *  End timestamp
 */

  string t_end = hrt ();
  cout << message_prefix
       << "MPI process " << processRank << ": execution ended at " << t_end << "."
       << endl;

/*
 *  Normal MPI termination
 */

  (void) MPI_Finalize ();

  return EXIT_SUCCESS;
}
