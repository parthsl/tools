//  Copyright (c) 2016 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com                 Last revised 23 March 2016

#include <iostream>
#include <sstream>
#include <string>

#include <cerrno>
#include <cstdlib>
#include <cstring>

#include <sys/types.h>
#include <sched.h>

#include "reporter.h"

using std::cerr; using std::cout; using std::endl;
using std::ostringstream;
using std::string;

string getCPUAffinity (vector<unsigned> lCPUID, pid_t p_or_t_id)
{
  extern string message_prefix;    //  This is assumed to have been
                                   // set prior to entry

  cpu_set_t *p_mask;

  size_t l_mask = CPU_ALLOC_SIZE (lCPUID.size ());

  if (l_mask < sizeof (cpu_set_t)) {
    l_mask = sizeof (cpu_set_t);
    p_mask = CPU_ALLOC (l_mask * 8);
  }
  else
    p_mask = CPU_ALLOC (lCPUID.size ());

  CPU_ZERO_S (l_mask, p_mask);
  if (sched_getaffinity (p_or_t_id, l_mask, p_mask) == -1) {
    cerr << message_prefix
         << "sched_getaffinity: " << strerror (errno) << "."
         << endl;
    exit (EXIT_FAILURE);
  }

  ostringstream cpu_affinity;
  unsigned int nBoundCPUs = 0;
  for (unsigned int i = 0; i < lCPUID.size (); ++i)
    if (CPU_ISSET_S (lCPUID[i], l_mask, p_mask)) {
      if (nBoundCPUs > 0)
        cpu_affinity << ", ";
      cpu_affinity << lCPUID[i];
      nBoundCPUs++;
    }

  CPU_FREE (p_mask);

  return cpu_affinity.str ();
}
