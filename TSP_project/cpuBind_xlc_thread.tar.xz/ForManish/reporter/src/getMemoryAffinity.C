//  Copyright (c) 2012 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com              Last revised 23 December 2012

#include <iostream>
#include <sstream>
#include <string>

#include <cerrno>
#include <cstdlib>
#include <cstring>

#include <numa.h>
#include <numaif.h>

#include "reporter.h"

using std::cerr; using std::cout; using std::endl;
using std::ostringstream;
using std::string;

string getMemoryAffinity ()
{
  extern string message_prefix;   // This is assumed to have
                                  // been setup before entry

  ostringstream mas;

  if (numa_available () == -1)
    mas << "memory policy not available";
  else {

    numa_exit_on_error = 1;
    unsigned long maxnode = numa_max_node ();

    int mode = 0;
    if (get_mempolicy (&mode, NULL, 0, 0, 0) == -1) {
      cerr << message_prefix
           << "get_mempolicy: " << strerror (errno) << "."
           << endl;
      exit (EXIT_FAILURE);
    }

    if (mode == MPOL_BIND) {
      mas << "bind policy: node(s)";
      struct bitmask *membind = numa_get_membind ();
      for (unsigned i = 0; i < numa_num_possible_nodes (); ++i) {
        if (numa_bitmask_isbitset (membind, i) == 1)
          mas << " " << i;
      }
    }
    else if (mode == MPOL_DEFAULT) {
      mas << "default policy: node: current";
    }
    else if (mode == MPOL_INTERLEAVE) {
      mas << "interleave policy: node(s)";
      struct bitmask *interleave = numa_get_interleave_mask ();
      for (unsigned i = 0; i < numa_num_possible_nodes (); ++i) {
        if (numa_bitmask_isbitset (interleave, i) == 1)
          mas << " " << i;
      }
    }
    else if (mode == MPOL_PREFERRED) {
      mas << "preferential policy: node ";
      unsigned long prefnode = numa_preferred ();
      mas << prefnode;
    }
    else {
      cerr << message_prefix
           << "get_mempolicy: unknown memory policy type."
           << endl;
      exit (EXIT_FAILURE);
    }
    
  }

  return mas.str ();
}
