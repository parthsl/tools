//  Copyright (c) 2016 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com                 Last revised 23 March 2016

#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <pthread.h>
#include <limits.h>
#include <unistd.h>
#include <sys/syscall.h>

#include "reporter.h"

using std::cerr; using std::cout; using std::endl;
using std::ostringstream;
using std::string;
using std::vector;

string message_prefix;

int n_threads;
vector<unsigned> lCPUID;
double interval;

struct thread_start_data {
  int rank;
};

struct thread_end_data {
  int status;
};

struct thread_end_data failure_data;

void *thread_start_routine (void *arg)
{
  extern int n_threads;
  extern struct thread_end_data failure_data;
  struct thread_start_data *start_data;
  struct thread_end_data *end_data;

  start_data = (struct thread_start_data *) arg;
  cout << message_prefix
       << "thread " << start_data->rank << " of " << n_threads << " threads started ... "
       << endl;

  pid_t tid = syscall (SYS_gettid);

  string CPUAffinity = getCPUAffinity (lCPUID, tid);
  cout << message_prefix
       << "thread " << start_data->rank << " (tid " << tid << ") can be scheduled to logical CPU(s) " << CPUAffinity << "."
       << endl;

  string MemAffinity = getMemoryAffinity ();
  cout << message_prefix
       << "thread " << start_data->rank << " (tid " << tid << "): " << MemAffinity << "."
       << endl;

  pause (interval);

  end_data = (struct thread_end_data *) malloc (sizeof (struct thread_end_data));
  if (end_data == NULL) {
    cerr << message_prefix
         << "thread_start_routine: malloc: " << strerror (errno) << "."
         << endl;
    return (void *) &failure_data;
  }
  else {
    end_data->status = EXIT_SUCCESS;
    return (void *) end_data;
  }
}

void error_handler (char *program_name, int exit_code)
{
    cerr << "Usage: " << program_name << " -n thread_count [-p pause_interval]\n"
         << " The thread count must equal or exceed 1; the (optional)\n"
         << " pause interval is a nonnegative decimal number." << endl;
    exit (exit_code);
}

int main (int argc, char *argv[])
{
  if (argc == 1)
    error_handler (argv[0], EXIT_FAILURE);

/*
 *  Set up the message prefix string
 */

  pid_t pid = getpid ();

  char hostname[HOST_NAME_MAX];
  if (gethostname (hostname, HOST_NAME_MAX) == -1) {
    cerr << argv[0] << ": "
         << "process " << pid << ": gethostname: " << strerror (errno) << "."
         << endl;
    exit (EXIT_FAILURE);
  }

  ostringstream mps;
  mps << argv[0] << " (PID " << pid << " on host " << hostname << "): ";
  message_prefix = mps.str ();

/*
 *  Start timestamp
 */

  string t_start = hrt ();

/*
 *  Establish the thread count and pause interval
 */

  interval = 0.;
  char *unconv;
  int opt;
  while ((opt = getopt (argc, argv, ":n:p:")) != -1) {
    switch (opt) {
      case 'n':
        n_threads = (int) strtol (optarg, &unconv, 0);
        if (strlen (unconv) > 0) {
          cerr << message_prefix
               << "string \"" << optarg << "\" cannot be converted to integer."
               << endl;
          error_handler (argv[0], EXIT_FAILURE);
        }
        if (n_threads < 1) {
          cerr << message_prefix
               << "number of threads (specified as " << optarg << ") must equal or exceed 1."
               << endl;
          error_handler (argv[0], EXIT_FAILURE);
        }
        break;
      case 'p':
        interval = strtod (optarg, &unconv);
        if (strlen (unconv) > 0) {
          cerr << message_prefix
               << "string \"" << optarg << "\" cannot be converted to double."
               << endl;
          error_handler (argv[0], EXIT_FAILURE);
        }
        if (interval < 0.) {
          cerr << message_prefix
               << "interval (specified as " << optarg << ") must be nonnegative."
               << endl;
          error_handler (argv[0], EXIT_FAILURE);
        }
        break;
      case ':':
        cerr << message_prefix
             << "missing option value."
             << endl;
        error_handler (argv[0], EXIT_FAILURE);
        break;
      case '?':
        cerr << message_prefix
             << "unrecognized option."
             << endl;
        error_handler (argv[0], EXIT_FAILURE);
        break;
      default:
        cerr << message_prefix
             << "unknown error."
             << endl;
        error_handler (argv[0], EXIT_FAILURE);
        break;
    }
  }

  if (n_threads == 0) {
    cerr << message_prefix
         << "thread count must be specified."
         << endl;
    error_handler (argv[0], EXIT_FAILURE);
  }

/*
 *  Return to normal operation
 */

  cout << message_prefix
       << "execution started at " << t_start << "." << endl;
/*
 *  Establish the list of logical CPUs
 */

  lCPUID = getCPUIDs ();

/*
 *  Check that the number of threads is tractable
 */

  if (n_threads > (unsigned long) sysconf (_SC_THREAD_THREADS_MAX)) {
    cerr << message_prefix
         << "the number of threads requested (" << n_threads << "),"
         << " exceeds the per-process maximum (" << sysconf (_SC_THREAD_THREADS_MAX) << ")."
         << endl;
    exit (EXIT_FAILURE);
  }
  pthread_t *thread_id = (pthread_t *) malloc (n_threads * sizeof (pthread_t));
  if (thread_id == NULL) {
    cerr << message_prefix
         << "malloc: " << strerror (errno) << "."
         << endl;
    exit (EXIT_FAILURE);
  }

  struct thread_start_data *start_data = (struct thread_start_data *) malloc (n_threads * sizeof (struct thread_start_data));
  if (thread_id == NULL) {
    cerr << message_prefix
         << "malloc: " << strerror (errno) << "."
         << endl;
    exit (EXIT_FAILURE);
  }

  failure_data.status = EXIT_FAILURE;

  for (int i = 1; i < n_threads; ++i) {
    start_data[i].rank = i;
    int rc = pthread_create (&thread_id[i],
                         NULL,
                         thread_start_routine,
                         (void *) &start_data[i]);
    if (rc != 0) {
      cerr << message_prefix
           << "pthread_create: " << strerror (rc) << "."
           << endl;
      exit (EXIT_FAILURE);
    }
  }
  start_data[0].rank = 0;
  struct thread_end_data *end_data = (struct thread_end_data *) thread_start_routine ((void *) &start_data[0]);
  cout << "Thread 0 completed with code " << end_data->status << "."
       << endl;
  if (end_data->status == EXIT_SUCCESS)
    free (end_data);
  for (int i = 1; i < n_threads; ++i) {
    int rc = pthread_join (thread_id[i],
                       (void **) &end_data);
    if (rc != 0) {
      cerr << message_prefix
           << "pthread_join: " << strerror (rc) << "."
           << endl;
      exit (EXIT_FAILURE);
    }
    cout << message_prefix
         << "thread " << i << " completed with code " << end_data->status
         << endl;
    if (end_data->status == EXIT_SUCCESS)
      free (end_data);
  }

/*
 *  End timestamp
 */

  string t_end = hrt ();
  cout << message_prefix
       << "execution ended at " << t_end << "."
       << endl;

  return EXIT_SUCCESS;
}
