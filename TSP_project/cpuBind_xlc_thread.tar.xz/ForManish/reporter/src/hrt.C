//  Copyright (c) 2012 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com              Last revised 23 December 2012

#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

#include <cerrno>
#include <cstdlib>
#include <cstring>

#include <time.h>
#include <sys/time.h>

using std::setfill; using std::setw;
using std::cerr; using std::cout; using std::endl;
using std::ostringstream;
using std::string;

string hrt ()
{
  extern string message_prefix;  // Assumed to have been
                                 // set up prior to call
  struct timeval stv;
  if (gettimeofday (&stv, NULL) == -1) {
    cerr << message_prefix
         << "hrt: gettimeofday: " << strerror (errno) << "."
         << endl;
    exit (EXIT_FAILURE);
  }

  struct tm *lt;
  if ((lt = localtime (&stv.tv_sec)) == NULL) {
    cerr << message_prefix
         << "hrt: localtime: " << strerror (errno) << "."
         << endl;
    exit (EXIT_FAILURE);
  }

  ostringstream hrt_str;
  hrt_str.str ("");
  hrt_str <<                                     1900 + lt->tm_year
          << "/" << setw (2) << setfill ('0') <<    1 + lt->tm_mon
          << "/" << setw (2) << setfill ('0') <<        lt->tm_mday
          << " "
          <<        setw (2) << setfill ('0') <<        lt->tm_hour
          << ":" << setw (2) << setfill ('0') <<        lt->tm_min
          << ":" << setw (2) << setfill ('0') <<        lt->tm_sec
          << "." << setw (6) << setfill ('0') <<        stv.tv_usec;

  return hrt_str.str ();
}
