//  Copyright (c) 2012 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com              Last revised 23 December 2012

#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include <cerrno>
#include <cstdlib>
#include <cstring>

#include <limits.h>
#include <numa.h>
#include <numaif.h>
#include <unistd.h>

#include "reporter.h"

using std::cerr; using std::cout; using std::endl;
using std::ostringstream;
using std::string;
using std::vector;

string message_prefix;

int main (int argc, char *argv[])
{
/*
 *  Set up the message prefix string
 */

  pid_t pid = getpid ();

  char hostname[HOST_NAME_MAX];
  if (gethostname (hostname, HOST_NAME_MAX) == -1) {
    cerr << argv[0] << ": "
         << "process " << pid << ": gethostname: " << strerror (errno) << "."
         << endl;
    return EXIT_FAILURE;
  }

  ostringstream mps;
  mps << argv[0] << " (PID " << pid << " on host " << hostname << "): ";
  message_prefix = mps.str ();

/*
 *  Start timestamp
 */

  string t_start = hrt ();
  cout << message_prefix
       << "execution started at " << t_start << "." << endl;

/*
 *  Establish the pause interval
 */

  double interval;
  if (argc == 1)
    interval = 0.;
  else if (argc == 2) {
    char *unconv;
    interval = strtod (argv[1], &unconv);
    if (strlen (unconv) > 0) {
      cerr << message_prefix
           << "string " << argv[1] << " cannot be converted to double."
           << endl;
      return EXIT_FAILURE;
    }
    if (interval < 0.) {
      cerr << message_prefix
           << "interval (specified as " << argv[1] << ") must be nonnegative."
           << endl;
      return EXIT_FAILURE;
    }
  }
  else {
    cerr << "Usage: " << argv[0] << " [interval]" << endl
         << " interval is a nonnegative number." << endl;
    return EXIT_FAILURE;
  }

/*
 *  Establish the list of logical CPUs
 */

  vector<unsigned> lCPUID = getCPUIDs ();

/*
 *  Establish and output the CPU affinity of this process
 */

  string CPUAffinity = getCPUAffinity (lCPUID, pid);

  cout << message_prefix
       << "can be scheduled to logical CPU(s) " << CPUAffinity << "."
       << endl;

/*
 *  Establish and output the memory affinity of this process
 */

  string MemoryAffinity = getMemoryAffinity ();
  cout << message_prefix
       << MemoryAffinity << "."
       << endl;

/*
 *  Execute the pause
 */

  pause (interval);

/*
 *  End timestamp
 */

  string t_end = hrt ();
  cout << message_prefix
       << "execution ended at " << t_end << "."
       << endl;

  return EXIT_SUCCESS;
}
