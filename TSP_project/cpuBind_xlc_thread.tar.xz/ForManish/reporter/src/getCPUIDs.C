//  Copyright (c) 2012 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com              Last revised 23 December 2012

#include <fstream>
#include <iostream>
#include <string>
#include <vector>

#include <cerrno>
#include <cstdlib>
#include <cstring>

#include "reporter.h"

using std::ifstream;
using std::cerr; using std::cout; using std::endl;
using std::string;
using std::vector;

vector<unsigned> getCPUIDs ()
{
  extern string message_prefix;  // This is assumed to have been
                                 // set prior to entry

  ifstream proc_cpuinfo ("/proc/cpuinfo");
  if (! proc_cpuinfo) {
    cerr << message_prefix
         << ": unable to open /proc/cpuinfo: " << strerror (errno) << "."
         << endl;
    exit (EXIT_FAILURE);
  }
  string word;
  vector<unsigned> lCPUIDs;
  while (proc_cpuinfo >> word) {
    if (word == "processor") {
      proc_cpuinfo >> word;
      unsigned unumval;
      proc_cpuinfo >> unumval;
      lCPUIDs.push_back (unumval);
    }
  }

  return lCPUIDs;
}
