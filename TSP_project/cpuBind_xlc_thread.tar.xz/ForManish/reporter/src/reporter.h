//  Copyright (c) 2012 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com              Last revised 23 December 2012

#ifndef REPORTER_H
#define REPORTER_H

#include <string>
#include <vector>

#include <sys/types.h>

using std::string;
using std::vector;

string getCPUAffinity (vector<unsigned> lCPUIDs, pid_t p_or_t_id);
vector<unsigned> getCPUIDs ();
string getMemoryAffinity ();
string hrt ();
void pause (double interval);

#endif
