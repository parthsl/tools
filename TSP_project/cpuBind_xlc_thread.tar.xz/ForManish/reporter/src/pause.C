//  Copyright (c) 2012 by IBM Corporation.  All rights reserved.
//  parpia@us.ibm.com; last revised 23 December 2012

#include <iostream>
#include <string>

#include <cerrno>
#include <cstdlib>
#include <cstring>

#include <limits.h>
#include <time.h>

#include "reporter.h"

using std::cerr; using std::cout; using std::endl;
using std::string;

void pause (double interval)
{
  extern string message_prefix;         // This is assumed to have been
                                        // set prior to entry
  struct timespec sts, rem;

  sts.tv_sec = (time_t) ((int) interval);
  sts.tv_nsec = (long) ((interval - ((int) interval)) * 1.e9);

  resume_fl:
  if (nanosleep (&sts, &rem) == -1) {
    if (errno == EINTR) {
      sts = rem;
      goto resume_fl;
    }
    else {
      cerr << message_prefix
           << "pause (" << interval << "): nanosleep: " << strerror (errno) << "."
           << endl;
      exit (EXIT_FAILURE);
    }
  }
}
