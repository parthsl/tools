// parpia@us.ibm.com  11 May 2016

#include <stdexcept>
#include <string>

#include <cstdlib>
#include <cstring>

#include "hybrid_launch.h"

using std::invalid_argument;
using std::string;

unsigned long unsignedlongRep (string stringRep)
{
  char *unconv;
  unsigned long numval = strtoul (stringRep.c_str (), &unconv, 0);
  if (strlen (unconv) > 0) {
    throw invalid_argument ("unsignedlongRep: string " + stringRep + " cannot be converted to long.");
  }
  return numval;
}
