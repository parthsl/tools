// parpia@us.ibm.com   11 May 2016

#include <stdexcept>
#include <string>

#include <cstdlib>

#include "hybrid_launch.h"

using std::runtime_error;
using std::string;

unsigned getGlobalTaskRank ()
{
  static unsigned taskRank = NOT_SET;

  if (taskRank == NOT_SET) {
    char *envValue;
    string envOMPI_COMM_WORLD_RANK;
    if (envValue = getenv ("OMPI_COMM_WORLD_RANK"))
      envOMPI_COMM_WORLD_RANK = envValue;
    if (envOMPI_COMM_WORLD_RANK == "")
      throw runtime_error ("getGlobalTaskRank: OpenMPI runtime environment (OMPI_COMM_WORLD_RANK) not established.");
    taskRank = static_cast<unsigned> (longRep (envOMPI_COMM_WORLD_RANK));
  }

  return taskRank;
}
