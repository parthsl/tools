// parpia@us.ibm.com  11 May 2016

#include <cstdlib>

#include "hybrid_launch.h"

bool isSetTARGET_CPU_LIST ()
{
  if (getenv ("TARGET_CPU_LIST"))
    return true;
  else
    return false;
}
