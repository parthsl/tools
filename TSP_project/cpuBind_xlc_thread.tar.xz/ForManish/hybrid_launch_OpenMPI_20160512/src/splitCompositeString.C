// parpia@us.ibm.com  11 May 2016

#include <string>
#include <vector>

#include "hybrid_launch.h"

using std::string;
using std::vector;

vector<string> splitCompositeString (string compositeString, const string delimiters)
{
  vector<string> listOfFields;
  string::size_type p_begin, p_end = 0;
  while (p_end < compositeString.size ()) {
    if ((p_begin = compositeString.find_first_not_of (delimiters, p_end)) == string::npos)
      break;
    if ((p_end = compositeString.find_first_of (delimiters, p_begin + 1)) == string::npos)
      p_end = compositeString.size ();
    string field = compositeString.substr (p_begin, p_end - p_begin);
    listOfFields.push_back (field);
    p_end++;
  }
  return listOfFields;
}
