// parpia@us.ibm.com  11 May 2016

#include <string>
#include <vector>

#include <cstdlib>
#include <cstring>

#include "hybrid_launch.h"

using std::string;
using std::vector;

void setOMP_PLACES (vector<unsigned> targetCPUIDList)
{
  char *envValue;
  string envOMP_PLACES = "OMP_PLACES=";

  for (vector<unsigned>::size_type i = 0; i < targetCPUIDList.size (); ++i) {
    envOMP_PLACES += stringRep (targetCPUIDList[i]);
    if (i < targetCPUIDList.size () - 1)
      envOMP_PLACES += ",";
  }

  char *cpEnvOMP_PLACES = (char *) malloc ((envOMP_PLACES.size () + 1) * sizeof (char));
  strcpy (cpEnvOMP_PLACES, envOMP_PLACES.c_str ());

  putenv (cpEnvOMP_PLACES);
}
