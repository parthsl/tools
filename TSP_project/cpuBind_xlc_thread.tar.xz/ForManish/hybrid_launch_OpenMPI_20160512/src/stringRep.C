// parpia@us.ibm.com  11 May 2016

#include <sstream>
#include <string>

#include "hybrid_launch.h"

using std::ostringstream;
using std::string;

string stringRep (long longRep)
{
  ostringstream oss;
  oss << longRep;

  return oss.str ();
}
