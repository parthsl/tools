// parpia@us.ibm.com  11 May 2016

#include <stdexcept>
#include <string>

#include <cerrno>
#include <cstring>

#include <unistd.h>

#include "hybrid_launch.h"

using std::runtime_error;
using std::string;

string getHostname ()
{
  char hostname[HOST_NAME_MAX];
  if (gethostname (hostname, HOST_NAME_MAX) == -1) {
    throw runtime_error ("getHostname: gethostname: "+ string (strerror (errno)) + ".");
  }
  return (string (hostname));
}
