// parpia@us.ibm.com  11 May 2016

#include <cstdlib>

#include "hybrid_launch.h"

bool isOMPIJob ()
{
  if (getenv ("OMPI_COMM_WORLD_SIZE") && getenv ("OMPI_COMM_WORLD_RANK"))
    return true;
  else
    return false;
}
