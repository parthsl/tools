// parpia@us.ibm.com  11 May 2016

#include <stdexcept>
#include <string>
#include <vector>

#include "hybrid_launch.h"

using std::invalid_argument;
using std::string;
using std::vector;

vector<unsigned> getTargetCPUList (string stringList)
{
  const string delimiters (" ,:;");
  vector<string> fields = splitCompositeString (stringList, delimiters);

  const string dash ("-");
  vector<unsigned> targetCPUList;
  for (vector<string>::size_type i = 0; i < fields.size (); ++i) {
    if (fields[i].find (dash) == string::npos)
      targetCPUList.push_back (static_cast <unsigned> (longRep (fields[i])));
    else {
      vector<string>subfields = splitCompositeString (fields[i], dash);
      if (subfields.size () > 2)
        throw invalid_argument ("getTargetCPUList: invalid range specification: " + fields[i] + ".");
      unsigned oneLimit = longRep (subfields[0]);
      unsigned anotherLimit = longRep (subfields[1]);
      if (anotherLimit > oneLimit)
        for (unsigned j = oneLimit; j <= anotherLimit; ++j)
          targetCPUList.push_back (j);
      else
        for (unsigned j = oneLimit; j >= anotherLimit; --j)
          targetCPUList.push_back (j);
    }
  }

  return targetCPUList;
}
