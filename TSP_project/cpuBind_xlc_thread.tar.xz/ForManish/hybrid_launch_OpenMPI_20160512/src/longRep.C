// parpia@us.ibm.com  11 May 2016

#include <stdexcept>
#include <string>

#include <cstdlib>
#include <cstring>

#include "hybrid_launch.h"

using std::invalid_argument;
using std::string;

long longRep (string stringRep)
{
  char *unconv;
  long numval = strtol (stringRep.c_str (), &unconv, 0);
  if (strlen (unconv) > 0) {
    throw invalid_argument ("longRep: string " + stringRep + " cannot be converted to long.");
  }
  return numval;
}
