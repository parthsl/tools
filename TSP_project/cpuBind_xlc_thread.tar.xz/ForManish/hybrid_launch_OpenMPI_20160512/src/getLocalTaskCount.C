// parpia@us.ibm.com  11 May 2016

#include <stdexcept>
#include <string>

#include <cstdlib>

#include "hybrid_launch.h"

using std::runtime_error;
using std::string;

unsigned getLocalTaskCount ()
{
  static unsigned hostTaskCount = NOT_SET;

  if (hostTaskCount == NOT_SET) {
    char *envValue;
    string envOMPI_COMM_WORLD_LOCAL_SIZE;
    if (envValue = getenv ("OMPI_COMM_WORLD_LOCAL_SIZE"))
      envOMPI_COMM_WORLD_LOCAL_SIZE = envValue;
    if (envOMPI_COMM_WORLD_LOCAL_SIZE == "")
      throw runtime_error ("getLocalTaskCount: OpenMPI runtime environment (OMPI_COMM_WORLD_LOCAL_SIZE) not established.");
    hostTaskCount = static_cast<unsigned> (longRep (envOMPI_COMM_WORLD_LOCAL_SIZE));
  }

  return hostTaskCount;
}
