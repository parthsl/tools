// Please send comments and corrections to
// Farid A. Parpia (parpia@us.ibm.com)
//                Last revised 12 May 2016

#include <algorithm>
#include <iostream>
#include <sstream>
#include <string>

#include <cerrno>
#include <cstdlib>
#include <cstring>

#include <unistd.h>
#include <sched.h>

#include "hybrid_launch.h"

using std::sort;
using std::cerr; using std::clog; using std::cout; using std::endl;
using std::ostringstream;
using std::string;

int main (int argc, char *argv[])
{
// Quit if no executable is specified or if the
// job is not an OpenMPI job or if the environment
// variable is not specified

  if (argc == 1 || !isOMPIJob () || !isSetTARGET_CPU_LIST ()) {
    cerr << "Usage: mpirun " << argv[0] << " myexe [myopts] [< myinp] [> myout]" << endl;
    cerr << " Additionally, environment variable TARGET_CPU_LIST must be set either" << endl;
    cerr << " to -1 (for automatic selection of target CPUIDs) or to a list of CPUIDs." << endl;
    return EXIT_FAILURE;
  }

// Establish the hostname

  string hostname = getHostname ();

// Establish the global rank of the present task

  unsigned taskRank = getGlobalTaskRank ();

// Establish the local task rank and count

  unsigned localTaskRank = getLocalTaskRank ();
  unsigned localTaskCount = getLocalTaskCount ();

// Establish the list of CPUIDs on this host
// and their cardinality

  vector<unsigned> sortedLogicalCPUIDList = getSortedLogicalCPUIDList ();
  vector<unsigned>::size_type nCPUs = sortedLogicalCPUIDList.size ();

// Establish the setting of the environment
// variable

  string envTARGET_CPU_LIST = getenv ("TARGET_CPU_LIST");

// Establish the OpenMP thread count

  unsigned nOMPThreads = getOMPThreadCount ();

// The number of threads is assumed to be the
// same for all tasks

  unsigned hostThreadCount = localTaskCount * nOMPThreads;

// Establish the list of logical CPUIDs to which
// the present task's threads are to be affinitized

  vector<unsigned> targetCPUIDList;

  if (envTARGET_CPU_LIST == "-1") {
    unsigned stride = nCPUs / hostThreadCount;
    if (stride == 0) {
      cerr << argv[0] << ": host " << hostname << ": aggregate thread count (" << hostThreadCount << ") exceeds logical CPU count (" << nCPUs << ")." << endl;
      stride = 1;
    }
    vector<unsigned> arityOrderedLogicalCPUIDList;
    while (arityOrderedLogicalCPUIDList.size () != nCPUs)
      for (int arity = 0; arity < 8; ++arity)
        for (int i = 0; i < sortedLogicalCPUIDList.size (); ++i)
          if (sortedLogicalCPUIDList[i] % 8 == arity)
             arityOrderedLogicalCPUIDList.push_back (sortedLogicalCPUIDList[i]);

    vector<unsigned>::size_type lList = sortedLogicalCPUIDList.size ();
    for (int i = 0; i < nOMPThreads; ++i)
      targetCPUIDList.push_back (arityOrderedLogicalCPUIDList[(localTaskRank * nOMPThreads + i) % lList]);
  }
  else {
    vector<unsigned> targetCPUList = getTargetCPUList (envTARGET_CPU_LIST);
    vector<unsigned>::size_type lList = targetCPUList.size ();
    if (hostThreadCount > lList)
      cerr << argv[0] << ": host " << hostname << ": aggregate thread count (" << hostThreadCount << ") exceeds length of list (" << lList << ") specified by TARGET_CPU_LIST." << endl;
    for (int i = 0; i < nOMPThreads; ++i)
      targetCPUIDList.push_back (targetCPUList[(localTaskRank * nOMPThreads + i) % lList]);

// Ensure that the selected CPUIDs are actually
// available

    for (vector<unsigned>::size_type i = 0; i < targetCPUIDList.size (); ++i) {
      bool found = false;
      for (vector<unsigned>::size_type j = 0; j < sortedLogicalCPUIDList.size (); ++j)
        if (sortedLogicalCPUIDList[j] == targetCPUIDList[i]) {
          found = true;
          break;
        }
      if (!found) {
        cerr << argv[0] << ": host " << hostname << ": logical CPUID " << targetCPUIDList[i] << " specified in TARGET_CPU_LIST is not available." << endl;
        exit (EXIT_FAILURE);
      }
    }

  }

// Set the various possible environment variables appropriately

  setGOMP_CPU_AFFINITY (targetCPUIDList);
//setOMP_PLACES (targetCPUIDList);
  setXLSMPOPTSprocs (targetCPUIDList);

// Establish the logical CPU for the prebind

  pid_t pid = getpid ();

// Bind the present process to all the selected CPUs

  cpu_set_t mask;
  CPU_ZERO(&mask);
  for (vector<unsigned>::size_type i = 0; i < targetCPUIDList.size (); ++i)
    CPU_SET(targetCPUIDList[i], &mask);
  if (sched_setaffinity (pid, sizeof (mask), &mask) == -1) {
    cerr << argv[0] << ": host " << hostname << ": sched_setaffinity: " << strerror (errno) << endl;
    return EXIT_FAILURE;
  }

// Now exec

  if (execvp (argv[1], &argv[1]) == -1) {
    cerr << argv[0] << ": host " << hostname << ": execvp (" << argv[1] << "): " << strerror (errno) << "." << endl;
    return EXIT_FAILURE;
  }

// Never executed, but required by the compiler

  return EXIT_SUCCESS;
}
