#ifndef HYBRID_LAUNCH_H
#define HYBRID_LAUNCH_H

#include <limits>
#include <string>
#include <vector>

#include <limits.h>
#include <time.h>

#ifndef HOST_NAME_MAX
#define HOST_NAME_MAX 255
#endif

using std::numeric_limits;
using std::string;
using std::vector;

const unsigned NOT_SET = numeric_limits<unsigned>::max ();

unsigned getGlobalTaskCount ();
unsigned getGlobalTaskRank ();
unsigned getHostCPUCount ();
string getHostname ();
unsigned getLocalTaskCount ();
unsigned getLocalTaskRank ();
unsigned getOMPThreadCount ();
vector<unsigned> getSortedLogicalCPUIDList ();
vector<unsigned> getTargetCPUList (string stringList);
bool isOMPIJob ();
bool isSetTARGET_CPU_LIST ();
long longRep (string stringRep);
void setGOMP_CPU_AFFINITY (vector<unsigned> targetCPUIDList);
void setOMP_PLACES (vector<unsigned> targetCPUIDList);
void setXLSMPOPTSprocs (vector<unsigned> targetCPUIDList);
vector<string> splitCompositeString (string compositeString, const string delimiters);
string stringRep (long longRep);
unsigned long unsignedlongRep (string stringRep);

#endif
