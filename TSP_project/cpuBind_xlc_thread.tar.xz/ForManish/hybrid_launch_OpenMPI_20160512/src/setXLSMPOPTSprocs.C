// parpia@us.ibm.com   21 April 2009

#include <string>
#include <vector>

#include <cstdlib>
#include <cstring>

#include "hybrid_launch.h"

using std::string;
using std::vector;

void setXLSMPOPTSprocs (vector<unsigned> targetCPUIDList)
{
  char *envValue;
  string envXLSMPOPTS;

  if (envValue = getenv ("XLSMPOPTS")) {
    envXLSMPOPTS = "XLSMPOPTS=" + string (envValue) + ":";
  }
  else
    envXLSMPOPTS = "XLSMPOPTS=";
  envXLSMPOPTS += "procs=";

  for (vector<unsigned>::size_type i = 0; i < targetCPUIDList.size (); ++i) {
    envXLSMPOPTS += stringRep (targetCPUIDList[i]);
    if (i < targetCPUIDList.size () - 1)
      envXLSMPOPTS += ",";
  }

  char *cpEnvXLSMPOPTS = (char *) malloc ((envXLSMPOPTS.size () + 1) * sizeof (char));
  strcpy (cpEnvXLSMPOPTS, envXLSMPOPTS.c_str ());

  putenv (cpEnvXLSMPOPTS);
}
