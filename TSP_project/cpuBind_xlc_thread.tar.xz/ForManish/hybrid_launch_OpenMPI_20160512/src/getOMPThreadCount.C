// parpia@us.ibm.com  11 May 2016

#include <stdexcept>
#include <string>
#include <vector>

#include <cstdlib>

#include "hybrid_launch.h"

using std::invalid_argument;
using std::string;
using std::vector;

unsigned getOMPThreadCount ()
{
  static unsigned OMPThreadCount = 0U;

  if (OMPThreadCount == 0U) {
    char *envValue;
    string envOMP_NUM_THREADS;
    string envXLSMPOPTS;
    if (envValue = getenv ("OMP_NUM_THREADS"))
       envOMP_NUM_THREADS = envValue;
    if (envValue = getenv ("XLSMPOPTS"))
       envXLSMPOPTS = envValue;
    if (envOMP_NUM_THREADS.size () > 0) {
      OMPThreadCount = unsignedlongRep (envOMP_NUM_THREADS);
    }
    else if (envXLSMPOPTS.size () > 0) {
      if (envXLSMPOPTS.find ("parthds") == string::npos)
        OMPThreadCount = getHostCPUCount ();
      else {
        vector<string> field = splitCompositeString (envXLSMPOPTS, ":");
        for (vector<string>::size_type i = 0; i < field.size (); ++i)
          if (field[i].find ("parthds") != string::npos) {
            vector<string> subfield  = splitCompositeString (field[i], "=");
            if (subfield.size () != 2)
              throw invalid_argument ("getOMPThreadCount: invalid specification: " + field[i] + ".");
            OMPThreadCount = unsignedlongRep (subfield[1]);
          }
      }
    }
    else
      OMPThreadCount = getHostCPUCount ();
  }

  return OMPThreadCount;
}
