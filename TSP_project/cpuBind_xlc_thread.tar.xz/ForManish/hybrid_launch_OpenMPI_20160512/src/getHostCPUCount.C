// parpia@us.ibm.com  11 May 2016

#include <fstream>
#include <string>

#include "hybrid_launch.h"

using std::ifstream;
using std::string;

unsigned getHostCPUCount ()
{
  static unsigned hostCPUCount = 0;

  if (hostCPUCount == 0) {
    ifstream file;
    file.open ("/proc/cpuinfo");
    string record;
    while (getline (file, record))
      if (record.substr (0,12) == "processor\t: ")
        hostCPUCount++;
  }

  return hostCPUCount;
}
