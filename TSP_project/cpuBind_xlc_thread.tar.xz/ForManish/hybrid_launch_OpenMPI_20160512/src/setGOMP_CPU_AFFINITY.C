// parpia@us.ibm.com  11 May 2016

#include <string>
#include <vector>

#include <cstdlib>
#include <cstring>

#include "hybrid_launch.h"

using std::string;
using std::vector;

void setGOMP_CPU_AFFINITY (vector<unsigned> targetCPUIDList)
{
  char *envValue;
  string envGOMP_CPU_AFFINITY = "GOMP_CPU_AFFINITY=";

  for (vector<unsigned>::size_type i = 0; i < targetCPUIDList.size (); ++i) {
    envGOMP_CPU_AFFINITY += stringRep (targetCPUIDList[i]);
    if (i < targetCPUIDList.size () - 1)
      envGOMP_CPU_AFFINITY += ",";
  }

  char *cpEnvGOMP_CPU_AFFINITY = (char *) malloc ((envGOMP_CPU_AFFINITY.size () + 1) * sizeof (char));
  strcpy (cpEnvGOMP_CPU_AFFINITY, envGOMP_CPU_AFFINITY.c_str ());

  putenv (cpEnvGOMP_CPU_AFFINITY);
}
