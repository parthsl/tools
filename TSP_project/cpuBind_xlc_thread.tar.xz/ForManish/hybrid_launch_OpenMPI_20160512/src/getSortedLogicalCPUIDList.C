// parpia@us.ibm.com  11 May 2016

#include <algorithm>
#include <fstream>
#include <string>
#include <vector>

#include "hybrid_launch.h"

using std::ifstream;
using std::vector;
using std::sort;
using std::string;

vector<unsigned> getSortedLogicalCPUIDList ()
{
  ifstream file;
  file.open ("/proc/cpuinfo");

  string record;
  vector<unsigned> logicalCPUList;

  while (getline (file, record))
    if (record.substr (0,12) == "processor\t: ")
      logicalCPUList.push_back (longRep (record.substr (12)));

  sort (logicalCPUList.begin (), logicalCPUList.end ());

  return logicalCPUList;
}
